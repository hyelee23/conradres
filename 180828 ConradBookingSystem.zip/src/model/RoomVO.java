package model;

public class RoomVO {
	//field
	private String rnumber;		//����ȣ��
	private String rname;		//�����̸�
	private int rprice;			//����1�ڴ簡��
	private int rbed;			//ħ�밳��
	private String rgrade;		//���ǵ��
	private String rview;		//���Ǻ�
	private boolean rguidedog;	//�ȳ������԰��ɿ���
	private int rstatus;		//���������Ȳ
//	1. ���൵ ���� üũ�ε� �ȵǾ��ִ� ��Ȳ / ��������
//	2. ������ ��������
//	3. üũ���� �Ǿ�����
	private String rimagename;	//�̹����̸�
	//
	public RoomVO() {
		super();
	}
	public RoomVO(String rnumber, String rname, int rprice, int rbed, String rgrade, String rview, boolean rguidedog,
			int rstatus, String rimagename) {
		super();
		this.rnumber = rnumber;
		this.rname = rname;
		this.rprice = rprice;
		this.rbed = rbed;
		this.rgrade = rgrade;
		this.rview = rview;
		this.rguidedog = rguidedog;
		this.rstatus = rstatus;
		this.rimagename = rimagename;
	}
	public RoomVO(String rname, int rprice, int rbed, String rgrade, String rview, boolean rguidedog, int rstatus,
			String rimagename) {
		super();
		this.rname = rname;
		this.rprice = rprice;
		this.rbed = rbed;
		this.rgrade = rgrade;
		this.rview = rview;
		this.rguidedog = rguidedog;
		this.rstatus = rstatus;
		this.rimagename = rimagename;
	}
	//
	public String getRnumber() {
		return rnumber;
	}
	public void setRnumber(String rnumber) {
		this.rnumber = rnumber;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public int getRprice() {
		return rprice;
	}
	public void setRprice(int rprice) {
		this.rprice = rprice;
	}
	public int getRbed() {
		return rbed;
	}
	public void setRbed(int rbed) {
		this.rbed = rbed;
	}
	public String getRgrade() {
		return rgrade;
	}
	public void setRgrade(String rgrade) {
		this.rgrade = rgrade;
	}
	public String getRview() {
		return rview;
	}
	public void setRview(String rview) {
		this.rview = rview;
	}
	public boolean isRguidedog() {
		return rguidedog;
	}
	public void setRguidedog(boolean rguidedog) {
		this.rguidedog = rguidedog;
	}
	public int getRstatus() {
		return rstatus;
	}
	public void setRstatus(int rstatus) {
		this.rstatus = rstatus;
	}
	public String getRimagename() {
		return rimagename;
	}
	public void setRimagename(String rimagename) {
		this.rimagename = rimagename;
	}
	
	
}
