package model;

public class GuestVO {
	//field
	private String gnumber;			//������ȣ
	private String gfamilyname;		//*��
	private String gfirstname;		//*�̸�	
	private String gphone;			//*����ȣ
	private String gaddress;			//*�ּ�
	private String gnationality;		//*����
	private String gpassport;		//���ǹ�ȣ
	private String gemail;			//�̸���
	private String gmembershipnum;	//�������ȣ
	private int gpoint;				//���������Ʈ
	//
	public GuestVO() {
		super();
	}
	//all
	public GuestVO(String gnumber, String gfamilyname, String gfirstname, String gphone, String gaddress,
			String gnationality, String gpassport, String gemail, String gmembershipnum, int gpoint) {
		super();
		this.gnumber = gnumber;
		this.gfamilyname = gfamilyname;
		this.gfirstname = gfirstname;
		this.gphone = gphone;
		this.gaddress = gaddress;
		this.gnationality = gnationality;
		this.gpassport = gpassport;
		this.gemail = gemail;
		this.gmembershipnum = gmembershipnum;
		this.gpoint = gpoint;
	}
	//without gn
	public GuestVO(String gfamilyname, String gfirstname, String gphone, String gaddress, String gnationality,
			String gpassport, String gemail, String gmembershipnum, int gpoint) {
		super();
		this.gfamilyname = gfamilyname;
		this.gfirstname = gfirstname;
		this.gphone = gphone;
		this.gaddress = gaddress;
		this.gnationality = gnationality;
		this.gpassport = gpassport;
		this.gemail = gemail;
		this.gmembershipnum = gmembershipnum;
		this.gpoint = gpoint;
	}
	//without membership
	public GuestVO(String gfamilyname, String gfirstname, String gphone, String gaddress, String gnationality) {
		super();
		this.gfamilyname = gfamilyname;
		this.gfirstname = gfirstname;
		this.gphone = gphone;
		this.gaddress = gaddress;
		this.gnationality = gnationality;
	}
	//
	public String getGnumber() {
		return gnumber;
	}
	public void setGnumber(String gnumber) {
		this.gnumber = gnumber;
	}
	public String getGfamilyname() {
		return gfamilyname;
	}
	public void setGfamilyname(String gfamilyname) {
		this.gfamilyname = gfamilyname;
	}
	public String getGfirstname() {
		return gfirstname;
	}
	public void setGfirstname(String gfirstname) {
		this.gfirstname = gfirstname;
	}
	public String getGphone() {
		return gphone;
	}
	public void setGphone(String gphone) {
		this.gphone = gphone;
	}
	public String getGaddress() {
		return gaddress;
	}
	public void setGaddress(String gaddress) {
		this.gaddress = gaddress;
	}
	public String getGnationality() {
		return gnationality;
	}
	public void setGnationality(String gnationality) {
		this.gnationality = gnationality;
	}
	public String getGpassport() {
		return gpassport;
	}
	public void setGpassport(String gpassport) {
		this.gpassport = gpassport;
	}
	public String getGemail() {
		return gemail;
	}
	public void setGemail(String gemail) {
		this.gemail = gemail;
	}
	public String getGmembershipnum() {
		return gmembershipnum;
	}
	public void setGmembershipnum(String gmembershipnum) {
		this.gmembershipnum = gmembershipnum;
	}
	public int getGpoint() {
		return gpoint;
	}
	public void setGpoint(int gpoint) {
		this.gpoint = gpoint;
	}
	
}
