package model;

public class CheckinVO {
	//field
	private String inumber;			//����üũ�ι�ȣ
	private String icheckin;		//üũ�γ�¥
	private String icheckout;		//üũ�ƿ���¥
	private String iroomsvc;		//�뼭�񽺳���
	private String isvc;			//�ΰ����񽺳���
	private String imemo;			//������û�޸�
	private boolean iearlychi;		//��üũ�ο���
	private boolean ilatecho;		//����Ʈüũ�ƿ�����
	private int itotalpay;			//�߰�����Ѿ�
	private String icardcompany;	//ī���
	private String icardnumber;		//ī���ȣ
	private int istatus;			//üũ�λ��� , 0üũ����, 1üũ�ε�, 2�մԿ�û��ҵ�, 3üũ�ξ���ä�γ�¥����(������)
	private String gnumber;			//������ȣ
	private String rnumber;			//���ǹ�ȣ
	private String bnumber;			//�����ȣ
	//
	public CheckinVO() {
		super();
	}
	public CheckinVO(String inumber, String icheckin, String icheckout, String iroomsvc, String isvc, String imemo,
			boolean iearlychi, boolean ilatecho, int itotalpay, String icardcompany, String icardnumber, int istatus,
			String gnumber, String rnumber, String bnumber) {
		super();
		this.inumber = inumber;
		this.icheckin = icheckin;
		this.icheckout = icheckout;
		this.iroomsvc = iroomsvc;
		this.isvc = isvc;
		this.imemo = imemo;
		this.iearlychi = iearlychi;
		this.ilatecho = ilatecho;
		this.itotalpay = itotalpay;
		this.icardcompany = icardcompany;
		this.icardnumber = icardnumber;
		this.istatus = istatus;
		this.gnumber = gnumber;
		this.rnumber = rnumber;
		this.bnumber = bnumber;
	}
	public CheckinVO(String icheckin, String icheckout, String iroomsvc, String isvc, String imemo, boolean iearlychi,
			boolean ilatecho, int itotalpay, String icardcompany, String icardnumber, int istatus, String gnumber,
			String rnumber, String bnumber) {
		super();
		this.icheckin = icheckin;
		this.icheckout = icheckout;
		this.iroomsvc = iroomsvc;
		this.isvc = isvc;
		this.imemo = imemo;
		this.iearlychi = iearlychi;
		this.ilatecho = ilatecho;
		this.itotalpay = itotalpay;
		this.icardcompany = icardcompany;
		this.icardnumber = icardnumber;
		this.istatus = istatus;
		this.gnumber = gnumber;
		this.rnumber = rnumber;
		this.bnumber = bnumber;
	}
	//
	public String getInumber() {
		return inumber;
	}
	public void setInumber(String inumber) {
		this.inumber = inumber;
	}
	public String getIcheckin() {
		return icheckin;
	}
	public void setIcheckin(String icheckin) {
		this.icheckin = icheckin;
	}
	public String getIcheckout() {
		return icheckout;
	}
	public void setIcheckout(String icheckout) {
		this.icheckout = icheckout;
	}
	public String getIroomsvc() {
		return iroomsvc;
	}
	public void setIroomsvc(String iroomsvc) {
		this.iroomsvc = iroomsvc;
	}
	public String getIsvc() {
		return isvc;
	}
	public void setIsvc(String isvc) {
		this.isvc = isvc;
	}
	public String getImemo() {
		return imemo;
	}
	public void setImemo(String imemo) {
		this.imemo = imemo;
	}
	public boolean isIearlychi() {
		return iearlychi;
	}
	public void setIearlychi(boolean iearlychi) {
		this.iearlychi = iearlychi;
	}
	public boolean isIlatecho() {
		return ilatecho;
	}
	public void setIlatecho(boolean ilatecho) {
		this.ilatecho = ilatecho;
	}
	public int getItotalpay() {
		return itotalpay;
	}
	public void setItotalpay(int itotalpay) {
		this.itotalpay = itotalpay;
	}
	public String getIcardcompany() {
		return icardcompany;
	}
	public void setIcardcompany(String icardcompany) {
		this.icardcompany = icardcompany;
	}
	public String getIcardnumber() {
		return icardnumber;
	}
	public void setIcardnumber(String icardnumber) {
		this.icardnumber = icardnumber;
	}
	public int getIstatus() {
		return istatus;
	}
	public void setIstatus(int istatus) {
		this.istatus = istatus;
	}
	public String getGnumber() {
		return gnumber;
	}
	public void setGnumber(String gnumber) {
		this.gnumber = gnumber;
	}
	public String getRnumber() {
		return rnumber;
	}
	public void setRnumber(String rnumber) {
		this.rnumber = rnumber;
	}
	public String getBnumber() {
		return bnumber;
	}
	public void setBnumber(String bnumber) {
		this.bnumber = bnumber;
	}
	
}