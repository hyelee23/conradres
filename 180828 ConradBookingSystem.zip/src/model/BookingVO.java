package model;

public class BookingVO {
	//field
	private String bnumber;			//�����ȣ
	private String bdate;			//�����ѳ�¥
	private String bcheckin;		//üũ�γ�¥
	private String bcheckout;		//üũ�ƿ���¥
	private int bpeople;			//�����ο�
	private int bpay;				//�����ݾ�
	private boolean bbreakfast;		//���Ŀ���
	private boolean blounge;		//������̿뿩��
	private boolean bguidedog;		//�ȳ��ߵ��ݿ���
	private boolean bparking;		//�����̿뿩��
	private String bcardcompany;	//ī���
	private String bcardnumber;		//ī���ȣ
	private int bstatus;			//�������, 0��������, 1�����, 2���࿡��üũ�����γѾ, 3����ܰ迡��������û�������, 4����ܰ迡���������, 5��Ÿ���������
	private String gnumber;			//������ȣ
	private String rnumber;			//����ȣ��
	//
	public BookingVO() {
		super();
	}
	public BookingVO(String bnumber, String bdate, String bcheckin, String bcheckout, int bpeople, int bpay,
			boolean bbreakfast, boolean blounge, boolean bguidedog, boolean bparking, String bcardcompany,
			String bcardnumber, int bctatus, String gnumber, String rnumber) {
		super();
		this.bnumber = bnumber;
		this.bdate = bdate;
		this.bcheckin = bcheckin;
		this.bcheckout = bcheckout;
		this.bpeople = bpeople;
		this.bpay = bpay;
		this.bbreakfast = bbreakfast;
		this.blounge = blounge;
		this.bguidedog = bguidedog;
		this.bparking = bparking;
		this.bcardcompany = bcardcompany;
		this.bcardnumber = bcardnumber;
		this.bstatus = bctatus;
		this.gnumber = gnumber;
		this.rnumber = rnumber;
	}
	public BookingVO(String bdate, String bcheckin, String bcheckout, int bpeople, int bpay, boolean bbreakfast,
			boolean blounge, boolean bguidedog, boolean bparking, String bcardcompany, String bcardnumber, int bctatus,
			String gnumber, String rnumber) {
		super();
		this.bdate = bdate;
		this.bcheckin = bcheckin;
		this.bcheckout = bcheckout;
		this.bpeople = bpeople;
		this.bpay = bpay;
		this.bbreakfast = bbreakfast;
		this.blounge = blounge;
		this.bguidedog = bguidedog;
		this.bparking = bparking;
		this.bcardcompany = bcardcompany;
		this.bcardnumber = bcardnumber;
		this.bstatus = bctatus;
		this.gnumber = gnumber;
		this.rnumber = rnumber;
	}
	//
	public String getBnumber() {
		return bnumber;
	}
	public void setBnumber(String bnumber) {
		this.bnumber = bnumber;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getBcheckin() {
		return bcheckin;
	}
	public void setBcheckin(String bcheckin) {
		this.bcheckin = bcheckin;
	}
	public String getBcheckout() {
		return bcheckout;
	}
	public void setBcheckout(String bcheckout) {
		this.bcheckout = bcheckout;
	}
	public int getBpeople() {
		return bpeople;
	}
	public void setBpeople(int bpeople) {
		this.bpeople = bpeople;
	}
	public int getBpay() {
		return bpay;
	}
	public void setBpay(int bpay) {
		this.bpay = bpay;
	}
	public boolean isBbreakfast() {
		return bbreakfast;
	}
	public void setBbreakfast(boolean bbreakfast) {
		this.bbreakfast = bbreakfast;
	}
	public boolean isBlounge() {
		return blounge;
	}
	public void setBlounge(boolean blounge) {
		this.blounge = blounge;
	}
	public boolean isBguidedog() {
		return bguidedog;
	}
	public void setBguidedog(boolean bguidedog) {
		this.bguidedog = bguidedog;
	}
	public boolean isBparking() {
		return bparking;
	}
	public void setBparking(boolean bparking) {
		this.bparking = bparking;
	}
	public String getBcardcompany() {
		return bcardcompany;
	}
	public void setBcardcompany(String bcardcompany) {
		this.bcardcompany = bcardcompany;
	}
	public String getBcardnumber() {
		return bcardnumber;
	}
	public void setBcardnumber(String bcardnumber) {
		this.bcardnumber = bcardnumber;
	}
	public int getBstatus() {
		return bstatus;
	}
	public void setBstatus(int bctatus) {
		this.bstatus = bctatus;
	}
	public String getGnumber() {
		return gnumber;
	}
	public void setGnumber(String gnumber) {
		this.gnumber = gnumber;
	}
	public String getRnumber() {
		return rnumber;
	}
	public void setRnumber(String rnumber) {
		this.rnumber = rnumber;
	}
	
}
