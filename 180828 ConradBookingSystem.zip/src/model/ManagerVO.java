package model;

public class ManagerVO {
	//field
	private String mnumber;	//�����ȣ
	private String mname;	//�̸�
	private String mid;		//���̵�
	private String mpw;		//�н�����
	private String mrank;	//����
	//
	public ManagerVO() {
		super();
	}
	public ManagerVO(String mnumber, String mname, String miD, String mpW, String mrank) {
		super();
		this.mnumber = mnumber;
		this.mname = mname;
		this.mid = miD;
		this.mpw = mpW;
		this.mrank = mrank;
	}
	public ManagerVO(String mname, String miD, String mpW, String mrank) {
		super();
		this.mname = mname;
		this.mid = miD;
		this.mpw = mpW;
		this.mrank = mrank;
	}
	public ManagerVO(String miD, String mpW) {
		super();
		this.mid = miD;
		this.mpw = mpW;
	}
	//
	public String getMnumber() {
		return mnumber;
	}
	public void setMnumber(String mnumber) {
		this.mnumber = mnumber;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getmID() {
		return mid;
	}
	public void setmID(String miD) {
		this.mid = miD;
	}
	public String getmPW() {
		return mpw;
	}
	public void setmPW(String mpW) {
		this.mpw = mpW;
	}
	public String getMrank() {
		return mrank;
	}
	public void setMrank(String mrank) {
		this.mrank = mrank;
	}
	
	
}
