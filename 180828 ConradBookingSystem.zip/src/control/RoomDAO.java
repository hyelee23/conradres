package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.RoomVO;

public class RoomDAO {
	
	//üũ�γ�¥, üũ�ƿ���¥, �ȳ��߿��η� ���� �˻��ؼ� ����� �ݳ��ϱ�
	public RoomVO searchBookingroom(String in, String out, int dog) throws Exception {
		
		RoomVO rVo = new RoomVO();
		
		String sql = "select * from room where rstatus=1 and rguidedog=?";
		//����Ʈ�� �ٽú���
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, dog);
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}		
		return rVo;
	}//üũ�γ�¥, üũ�ƿ���¥, �ȳ��߿��η� ���� �˻��ؼ� ����� �ݳ��ϱ�
	
	
	//���� ȣ����ȣ�� �������� �ݳ��ϱ�
	public RoomVO searchRoominfo(String number) throws Exception {
		
		RoomVO rVo = new RoomVO();
		
		String sql = "select * from room where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, number);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				rVo.setRnumber(rs.getString(1));	//����ȯ
				rVo.setRname(rs.getString(2));
				rVo.setRprice(rs.getInt(3));
				rVo.setRbed(rs.getInt(4));
				rVo.setRgrade(rs.getString(5));
				rVo.setRview(rs.getString(6));
				if(rs.getInt(7)==0) {
					rVo.setRguidedog(true);
				} else if (rs.getInt(7)==1) {
					rVo.setRguidedog(false);
				}
				rVo.setRstatus(rs.getInt(8));
				rVo.setRimagename(rs.getString(9));
			} else {
				rVo.setRname("0");
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}		
		
		return rVo;
	}//���� ȣ����ȣ�� �������� �ݳ��ϱ�
	
	
	//���ǵ���ϱ�
	public boolean insertRoominfo(RoomVO rVo) throws Exception {
		
		boolean result = false;	//true=success, false=fail
		
		String sql = "insert into room values "
				+ "(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(rVo.getRnumber()));
			pstmt.setString(2, rVo.getRname());
			pstmt.setInt(3, rVo.getRprice());
			pstmt.setInt(4, rVo.getRbed());
			pstmt.setString(5, rVo.getRgrade());
			pstmt.setString(6, rVo.getRview());
			if(rVo.isRguidedog()) {
				pstmt.setInt(7, 0);
			} else {
				pstmt.setInt(7, 1);
			}
			pstmt.setInt(8, 0);
			pstmt.setString(9, rVo.getRimagename());
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result=true;
			} else {
				result=false;
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}		
		
		return result;
	}//���ǵ���ϱ�
	
	
	//���ǹ�ȣ �˻��ؼ� ��ȿ���� Ȯ���ϱ�
	public boolean checkRoomnumber(String number) throws Exception {
		
		boolean result=false;
		
		String sql = "select * from room where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, number);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result=true;
			} else {
				result=false;
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//���ǹ�ȣ �˻��ؼ� ��ȿ���� Ȯ���ϱ�
	
	
	//�������� �����ϱ�
	public boolean updateRoominfo(RoomVO rVo) throws Exception {
		
		boolean result=false;
		
		String sql = "update room set "
				+ "rname=?, rprice=?, rbed=?, rgrade=?, rview=?, rguidedog=?, "
				+ "rstatus=? "
				+ "where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, rVo.getRname());
			pstmt.setInt(2, rVo.getRprice());
			pstmt.setInt(3, rVo.getRbed());
			pstmt.setString(4, rVo.getRgrade());
			pstmt.setString(5, rVo.getRview());
			if(rVo.isRguidedog()) {
				pstmt.setInt(6, 0);
			} else {
				pstmt.setInt(6, 1);
			}
			pstmt.setInt(7, 0);
			pstmt.setInt(8, Integer.parseInt(rVo.getRnumber()));
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result=true;
			} else {
				result=false;
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//�������� �����ϱ�
	
	
	//���� ���¸� üũ�� ���·� �ٲٱ� status 0->1
	public boolean updateRoomStatusIN(String rnumber) throws Exception {
		
		boolean result = false;
		
		String sql = "update room set rstatus=1 where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, rnumber);
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
				System.out.println(101010);
			} else {
				result = false;
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//���� ���¸� üũ�� ���·� �ٲٱ� status 0->1

	
	//���� ���¸� üũ�ƿ� ���·� �ٲٱ� status 1->0
	public boolean updateRoomStatusOUT(String rnumber) throws Exception {
		boolean result = false;
		
		String sql = "update room set rstatus=0 where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, rnumber);
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
			} else {
				result = false;
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//���� ���¸� üũ�ƿ� ���·� �ٲٱ� status 1->0
	
	
	//���� ���¸� ��ȯ�ϱ�
	public ArrayList<RoomVO> checkRoomstatus() throws Exception {
		
		ArrayList<RoomVO> list = new ArrayList<RoomVO>();
		RoomVO rVo = null;
		
		String sql = "select * from room";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				rVo = new RoomVO();
				
				rVo.setRnumber(rs.getString(1));
				rVo.setRname(rs.getString(2));
				rVo.setRprice(rs.getInt(3));
				rVo.setRbed(rs.getInt(4));
				rVo.setRgrade(rs.getString(5));
				rVo.setRview(rs.getString(6));
				if(rs.getInt(7)==0) {
					rVo.setRguidedog(true);
				} else if (rs.getInt(7)==1) {
					rVo.setRguidedog(false);
				}
				rVo.setRstatus(rs.getInt(8));
				rVo.setRimagename(rs.getString(9));
				
				list.add(rVo);
				
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return list;
	}//���� ���¸� ��ȯ�ϱ�
	
	
	//��ѹ��� �Ϸ�ġ ���� ��ȯ�ϱ�
	public int searchpaymentbyRnum(String rnum) throws Exception {
		int paynight=0;
		
		String sql = "select rprice from room where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, rnum);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				paynight = rs.getInt(1);
			}
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return paynight;
	}//��ѹ��� �Ϸ�ġ ���� ��ȯ�ϱ�
}
