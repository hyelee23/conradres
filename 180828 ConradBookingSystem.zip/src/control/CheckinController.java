package control;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.BookingVO;
import model.CheckinVO;

public class CheckinController implements Initializable{
	@FXML private VBox vboxcheckin;
	@FXML private Label txtToday;
	@FXML private TextField txtFamilyname;
	@FXML private TextField txtFirstname;
	@FXML private Button btnSearch;
	@FXML private ComboBox<String> cbBooklist;
	@FXML private Button btnLoad;
	@FXML private TextField txtBookname;
	@FXML private Label txtCheckin;
	@FXML private Label txtCheckout;
	@FXML private Label txtNight;
	@FXML private Label txtPeople;
	@FXML private Label txtOptBreakfast;
	@FXML private Label txtOptLounge;
	@FXML private Label txtOptGog;
	@FXML private Label txtOptParking;
	@FXML private CheckBox chbEarlychi;
	@FXML private TextField txtRoomnum;
	@FXML private Button btnSave;
	@FXML private Button btnExit;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//set style
		vboxcheckin.setStyle("-fx-background-image: url('/images/checkinback.png');");
		btnSearch.setStyle("-fx-base: #bdb286;");
		cbBooklist.setStyle("-fx-base: #bdb286;");
		btnLoad.setStyle("-fx-base: #bdb286;");
		chbEarlychi.setStyle("-fx-base: #bdb286;");
		btnSave.setStyle("-fx-base: #bdb286;");
		btnExit.setStyle("-fx-base: #bdb286;");
		
		//üũ�γ�¥ ���糯¥�� �ڵ�����
		txtToday.setText(LocalDate.now().toString());
		
		//�����̸����� ���೻�� �˻���ư
		btnSearch.setOnAction(event->handlerBtnSearchAction(event));
		//�����ȣ �ε���ư
		btnLoad.setOnAction(event->handlerBtnLoadAction(event));
		//üũ�� ���� ��ư
		btnSave.setOnAction(event->handlerBtnSaveAction(event));
		//�ݱ��ư
		btnExit.setOnAction(event->handlerBtnExitAction(event));
		
	}

	
	//�����̸����� ���೻�� �˻���ư
	public void handlerBtnSearchAction(ActionEvent event) {
		String familyname;
		String firstname;
		String gnum;
		String bnum;
		
		familyname=txtFamilyname.getText();
		firstname=txtFirstname.getText();
		
		GuestDAO gDao = new GuestDAO();
		BookingDAO bDao = new BookingDAO();
		ArrayList<String> list = null;
		ArrayList<String> numberlist = null;
		ArrayList<String> finallist = new ArrayList<String>();
		
		try {
			list = gDao.searchGuestnum(familyname, firstname);
			System.out.println(list.size());
			for(int i=0 ; i<list.size() ; i++) {
				gnum = list.get(i);
				numberlist = bDao.searchBookingnum(gnum);
				System.out.println(numberlist.size());
				for(int j=0 ; j<numberlist.size() ; j++) {
					bnum = numberlist.get(j);
					finallist.add(bnum);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		cbBooklist.setItems(FXCollections.observableArrayList(finallist));
				
	}//�����̸����� ���೻�� �˻���ư


	//�����ȣ �ε���ư
	public void handlerBtnLoadAction(ActionEvent event) {
		
		String number = cbBooklist.getValue().toString();
		int night;
		
		BookingDAO bDao = new BookingDAO();
		BookingVO bVo = new BookingVO();
		
		try {
			bVo = bDao.getBookinginfobyNum(number);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		txtBookname.setText(bVo.getBnumber());
		txtCheckin.setText(bVo.getBcheckin());
		txtCheckout.setText(bVo.getBcheckout());
		
		night = bVo.getBcheckout().compareTo(bVo.getBcheckin());
		txtNight.setText(night+"");

		txtPeople.setText(bVo.getBpeople()+"");
		
		txtOptBreakfast.setText(bVo.isBbreakfast()+"");
		txtOptLounge.setText(bVo.isBlounge()+"");
		txtOptGog.setText(bVo.isBguidedog()+"");
		txtOptParking.setText(bVo.isBparking()+"");
		
		txtRoomnum.setText(bVo.getRnumber());
		txtRoomnum.setEditable(false);
		
		
	}//�����ȣ �ε���ư


	//üũ�� ���� ��ư
	public void handlerBtnSaveAction(ActionEvent event) {
		
		String bnum = null;
		String rnum = null;
		String gnum = null;
		boolean result1 = false;
		boolean result2 = false;
		boolean result3 = false;
		
		CheckinVO cVo = new CheckinVO();
		CheckinDAO cDao = new CheckinDAO();
		BookingDAO bDao = new BookingDAO();
		RoomDAO rDao = new RoomDAO();
		
		bnum = txtBookname.getText();
		rnum = txtRoomnum.getText();
		
		cVo.setIcheckin(txtCheckin.getText());
		cVo.setIcheckout(txtCheckout.getText());
		if(chbEarlychi.isSelected()) {
			cVo.setIearlychi(true);
		} else {
			cVo.setIearlychi(false);
		}
		cVo.setItotalpay(0);
		cVo.setIstatus(1);	//������üũ�ε�
		try {
			gnum = bDao.getGnumberbyBnumber(bnum);
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		cVo.setGnumber(gnum);
		cVo.setRnumber(rnum);
		cVo.setBnumber(bnum);
		
		
		try {
			//üũ�����̺��� ���ο� üũ�ε����͸� �ִ´�
			result1 = cDao.insertCheckin(cVo);
			//���൥������ status�� 2������ �ٲ��� = üũ�ε�
			result2 = bDao.updateBookingStatusIN(bnum);
			//���ǵ������� status�� 1������ �ٲ��� = üũ�ε�
			result3 = rDao.updateRoomStatusIN(rnum);
		} catch (Exception e2) {
			e2.printStackTrace();
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("üũ�� ����");
			alert.setHeaderText("üũ�ο� �����߽��ϴ�");
			alert.setContentText("�˼��մϴ�");
			alert.showAndWait();
		}
		
		if(result1) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("üũ�� �Ϸ�");
			alert.setHeaderText("üũ���� �Ϸ�Ǿ����ϴ�");
			alert.setContentText("�����մϴ�");
			alert.showAndWait();
			
			//�ʵ��ʱ�ȭ
			txtFamilyname.clear();
			txtFirstname.clear();
			cbBooklist.setItems(FXCollections.observableArrayList(" "));
			txtBookname.clear();
			txtCheckin.setText(" ");
			txtCheckout.setText(" ");
			txtNight.setText(" ");
			txtPeople.setText(" ");
			txtOptBreakfast.setText(" ");
			txtOptLounge.setText(" ");
			txtOptGog.setText(" ");
			txtOptParking.setText(" ");
			chbEarlychi.setSelected(false);
			txtRoomnum.clear();
		} 
		
	}//üũ�� ���� ��ư


	//�ݱ��ư
	public void handlerBtnExitAction(ActionEvent event) {
		Stage oldStage = (Stage) btnExit.getScene().getWindow();
        oldStage.close();
	}//�ݱ��ư

}
