package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.CheckinVO;
import model.RoomVO;

public class RoomstatusController implements Initializable {
	@FXML private VBox vboxroomstatus;
	//
	@FXML private HBox floor21;
	@FXML private Button room2101;
	@FXML private Button room2102;
	//
	@FXML private HBox floor20;
	@FXML private Button room2001;
	@FXML private Button room2002;
	@FXML private Button room2003;
	@FXML private Button room2004;
	@FXML private Button room2005;
	//
	@FXML private HBox floor19;
	@FXML private Button room1901;
	@FXML private Button room1902;
	@FXML private Button room1903;
	@FXML private Button room1904;
	@FXML private Button room1905;
	@FXML private Button room1906;
	@FXML private Button room1907;
	@FXML private Button room1908;
	//
	@FXML private HBox floor18;
	@FXML private Button room1801;
	@FXML private Button room1802;
	@FXML private Button room1803;
	@FXML private Button room1804;
	@FXML private Button room1805;
	@FXML private Button room1806;
	@FXML private Button room1807;
	@FXML private Button room1808;
	@FXML private Button room1809;
	@FXML private Button room1810;
	//
	@FXML private HBox floor17;
	@FXML private Button room1701;
	@FXML private Button room1702;
	@FXML private Button room1703;
	@FXML private Button room1704;
	@FXML private Button room1705;
	@FXML private Button room1706;
	@FXML private Button room1707;
	@FXML private Button room1708;
	@FXML private Button room1709;
	@FXML private Button room1710;
	//
	@FXML private HBox floor16;
	@FXML private Button room1601;
	@FXML private Button room1602;
	@FXML private Button room1603;
	@FXML private Button room1604;
	@FXML private Button room1605;
	@FXML private Button room1606;
	@FXML private Button room1607;
	@FXML private Button room1608;
	@FXML private Button room1609;
	@FXML private Button room1610;
	//
	@FXML private Button btnExit;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//style setting
		vboxroomstatus.setStyle("-fx-background-image: url('/images/roomstatusback.png');");
		room2101.setStyle("-fx-base: #e6debf;");
		room2102.setStyle("-fx-base: #e6debf;");
		room2001.setStyle("-fx-base: #e6debf;");
		room2002.setStyle("-fx-base: #e6debf;");
		room2003.setStyle("-fx-base: #e6debf;");
		room2004.setStyle("-fx-base: #e6debf;");
		room2005.setStyle("-fx-base: #e6debf;");
		room1901.setStyle("-fx-base: #e6debf;");
		room1902.setStyle("-fx-base: #e6debf;");
		room1903.setStyle("-fx-base: #e6debf;");
		room1904.setStyle("-fx-base: #e6debf;");
		room1905.setStyle("-fx-base: #e6debf;");
		room1906.setStyle("-fx-base: #e6debf;");
		room1907.setStyle("-fx-base: #e6debf;");
		room1908.setStyle("-fx-base: #e6debf;");
		room1801.setStyle("-fx-base: #e6debf;");
		room1802.setStyle("-fx-base: #e6debf;");
		room1803.setStyle("-fx-base: #e6debf;");
		room1804.setStyle("-fx-base: #e6debf;");
		room1805.setStyle("-fx-base: #e6debf;");
		room1806.setStyle("-fx-base: #e6debf;");
		room1807.setStyle("-fx-base: #e6debf;");
		room1808.setStyle("-fx-base: #e6debf;");
		room1809.setStyle("-fx-base: #e6debf;");
		room1810.setStyle("-fx-base: #e6debf;");
		room1701.setStyle("-fx-base: #e6debf;");
		room1702.setStyle("-fx-base: #e6debf;");
		room1703.setStyle("-fx-base: #e6debf;");
		room1704.setStyle("-fx-base: #e6debf;");
		room1705.setStyle("-fx-base: #e6debf;");
		room1706.setStyle("-fx-base: #e6debf;");
		room1707.setStyle("-fx-base: #e6debf;");
		room1708.setStyle("-fx-base: #e6debf;");
		room1709.setStyle("-fx-base: #e6debf;");
		room1710.setStyle("-fx-base: #e6debf;");
		room1601.setStyle("-fx-base: #e6debf;");
		room1602.setStyle("-fx-base: #e6debf;");
		room1603.setStyle("-fx-base: #e6debf;");
		room1604.setStyle("-fx-base: #e6debf;");
		room1605.setStyle("-fx-base: #e6debf;");
		room1606.setStyle("-fx-base: #e6debf;");
		room1607.setStyle("-fx-base: #e6debf;");
		room1608.setStyle("-fx-base: #e6debf;");
		room1609.setStyle("-fx-base: #e6debf;");
		room1610.setStyle("-fx-base: #e6debf;");
		btnExit.setStyle("-fx-base: #bdb286;");
		
		//
		room2101.setOnAction(event->handlerBtnRoomnumberAction(event));
		room2102.setOnAction(event->handlerBtnRoomnumberAction(event));
		//
		room2001.setOnAction(event->handlerBtnRoomnumberAction(event));
		room2002.setOnAction(event->handlerBtnRoomnumberAction(event));
		room2003.setOnAction(event->handlerBtnRoomnumberAction(event));
		room2004.setOnAction(event->handlerBtnRoomnumberAction(event));
		room2005.setOnAction(event->handlerBtnRoomnumberAction(event));
		//
		room1901.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1902.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1903.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1904.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1905.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1906.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1907.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1908.setOnAction(event->handlerBtnRoomnumberAction(event));
		//
		room1801.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1802.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1803.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1804.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1805.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1806.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1807.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1808.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1809.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1810.setOnAction(event->handlerBtnRoomnumberAction(event));
		//
		room1701.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1702.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1703.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1704.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1705.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1706.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1707.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1708.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1709.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1710.setOnAction(event->handlerBtnRoomnumberAction(event));
		//
		room1601.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1602.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1603.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1604.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1605.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1606.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1607.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1608.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1609.setOnAction(event->handlerBtnRoomnumberAction(event));
		room1610.setOnAction(event->handlerBtnRoomnumberAction(event));
		
		//�ݱ��ư
		btnExit.setOnAction(event->handlerBtnExitAction(event));
		
		//����¿� ���� ��ư �����ϱ�
		settingRoombutton();
		
	}

	
	//����¿� ���� ��ư �����ϱ�
	public void settingRoombutton() {
		ArrayList<RoomVO> list = null;
		RoomDAO rDao = new RoomDAO();
		RoomVO rVo = null;
		String roomnum;
		
		try {
			list = rDao.checkRoomstatus();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("list error");
		}
		
		for(int i=0 ; i < list.size() ; i++) {
			rVo = list.get(i);
			
			if(rVo.getRstatus()==1) {	//üũ�εǾ��ִٸ�
				roomnum = rVo.getRnumber();
				
				switch(roomnum) {
				//floor21
				case "2101" :
					room2101.setStyle("-fx-base: #6fd5e3;");
					break;
				case "2102" :
					room2102.setStyle("-fx-base: #6fd5e3;");
					break;
				//floor20
				case "2001" :
					room2001.setStyle("-fx-base: #6fd5e3;");
					break;
				case "2002" :
					room2002.setStyle("-fx-base: #6fd5e3;");
					break;
				case "2003" :
					room2003.setStyle("-fx-base: #6fd5e3;");
					break;
				case "2004" :
					room2004.setStyle("-fx-base: #6fd5e3;");
					break;
				case "2005" :
					room2005.setStyle("-fx-base: #6fd5e3;");
					break;
				//floor19
				case "1901" :
					room1901.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1902" :
					room1902.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1903" :
					room1903.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1904" :
					room1904.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1905" :
					room1905.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1906" :
					room1906.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1907" :
					room1907.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1908" :
					room1908.setStyle("-fx-base: #6fd5e3;");
					break;
				//floor18
				case "1801" :
					room1801.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1802" :
					room1802.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1803" :
					room1803.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1804" :
					room1804.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1805" :
					room1805.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1806" :
					room1806.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1807" :
					room1807.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1808" :
					room1808.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1809" :
					room1809.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1810" :
					room1810.setStyle("-fx-base: #6fd5e3;");
					break;
				//floor17
				case "1701" :
					room1701.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1702" :
					room1702.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1703" :
					room1703.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1704" :
					room1704.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1705" :
					room1705.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1706" :
					room1706.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1707" :
					room1707.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1708" :
					room1708.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1709" :
					room1709.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1710" :
					room1710.setStyle("-fx-base: #6fd5e3;");
					break;
				//floor16
				case "1601" :
					room1601.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1602" :
					room1602.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1603" :
					room1603.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1604" :
					room1604.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1605" :
					room1605.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1606" :
					room1606.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1607" :
					room1607.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1608" :
					room1608.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1609" :
					room1609.setStyle("-fx-base: #6fd5e3;");
					break;
				case "1610" :
					room1610.setStyle("-fx-base: #6fd5e3;");
					break;
				default :
					break;
				}
				
				//room2101.setStyle("-fx-base: #b6e7c9;");
				//button.setStyle("-fx-background-color: white; -fx-padding: 10px;");
			}
		}
		
	}//����¿� ���� ��ư �����ϱ�


	//�ݱ��ư
	public void handlerBtnExitAction(ActionEvent event) {
		Stage oldStage = (Stage) btnExit.getScene().getWindow();
        oldStage.close();
	}//�ݱ��ư

	
	//���� ��ư ��������
	public void handlerBtnRoomnumberAction(ActionEvent event) {
		
		Button selectedroom = (Button) event.getTarget();
		String number = selectedroom.getText();
		
		CheckinVO cVo = new CheckinVO();
		CheckinDAO cDao = new CheckinDAO();
		RoomVO rVo = new RoomVO();
		RoomDAO rDao = new RoomDAO();
		
		try {
			
			Parent room = FXMLLoader.load(getClass().getResource("/view/room.fxml"));
			Scene newScene = new Scene(room);
			Stage primaryStage = new Stage();
			primaryStage.setTitle("��������");
			primaryStage.setScene(newScene);
			primaryStage.setResizable(false);
			Stage oldStage = (Stage) selectedroom.getScene().getWindow();
	        oldStage.close();
			primaryStage.show();
			
			Label thisroomnumber = (Label) room.lookup("#txtRoomnumber");
			Label thisinumber = (Label) room.lookup("#txtinumber");
			ImageView thisimgRoom = (ImageView) room.lookup("#imgRoom");
			Label thisroomname = (Label) room.lookup("#txtRoomname");
			Label thisoptbed = (Label) room.lookup("#txtoptbed");
			Label thisoptgrade = (Label) room.lookup("#txtoptgrade");
			Label thisoptview = (Label) room.lookup("#txtoptview");
			Label thisoptdog = (Label) room.lookup("#txtoptdog");
			TextField thisguestnum = (TextField) room.lookup("#txtGuestnum");
			TextField thischeckin = (TextField) room.lookup("#txtCheckin");
			TextField thischeckout = (TextField) room.lookup("#txtCheckout");
			TextArea thisroomsvc = (TextArea) room.lookup("#txtRoomsvc");
			TextArea thissvc = (TextArea) room.lookup("#txtSvc");
			TextArea thismemo = (TextArea) room.lookup("#txtMemo");
			TextField thisaddifee = (TextField) room.lookup("#txtAdditionalfee");
			Button thisguest = (Button) room.lookup("#btnGuest");
			Button thissave = (Button) room.lookup("#btnSave");
			Button thisbtncho = (Button) room.lookup("#btnCheckout");
			
			rVo = rDao.searchRoominfo(number);
			
			thisroomnumber.setText(number);
			String url = "file:/C:\\Temp\\conradseoul/"+rVo.getRimagename();
			thisimgRoom.setImage(new Image(url, false));
			thisroomname.setText(rVo.getRname());
			thisoptbed.setText(rVo.getRbed()+"");
			thisoptgrade.setText(rVo.getRgrade());
			thisoptview.setText(rVo.getRview());
			thisoptdog.setText(rVo.isRguidedog()+"");
			
			if(rVo.getRstatus()==1) {	//üũ�ε� �մ�����
				cVo = cDao.getCheckininfobyRnum(number);
				thisinumber.setText(cVo.getInumber());
				thisguestnum.setText(cVo.getGnumber());
				thischeckin.setText(cVo.getIcheckin());
				thischeckout.setText(cVo.getIcheckout());
				thisroomsvc.setText(cVo.getIroomsvc());
				thissvc.setText(cVo.getIsvc());
				thismemo.setText(cVo.getImemo());
				thisaddifee.setText(cVo.getItotalpay()+"");
			} else {
				thisguestnum.setDisable(true);
				thischeckin.setDisable(true);
				thischeckout.setDisable(true);
				thisroomsvc.setDisable(true);
				thissvc.setDisable(true);
				thismemo.setDisable(true);
				thisaddifee.setDisable(true);
				thisguest.setDisable(true);
				thissave.setDisable(true);
				thisbtncho.setDisable(true);
			}
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	} //���� ��ư ��������

}
