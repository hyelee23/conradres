package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.CheckinVO;

public class CheckinDAO {
	
	
	//üũ�� ����ϱ�
	public boolean insertCheckin(CheckinVO cVo) throws Exception {
		boolean result = false;
		String chi = cVo.getIcheckin();
		String cho = cVo.getIcheckout();
		
		System.out.println("insert checkin start");
		
		System.out.println(chi);
		System.out.println(cho);
		
		String sql = "insert into checkin values (checkinnum_seq.nextval, "
				+ " to_date('"+chi+"','YYYY-MM-DD'), to_date('"+cho+"','YYYY-MM-DD'), "	//üũ��, üũ�ƿ�
				+ " ' ', ' ', ' ', ?, 1, "	//�뼭��, ����, �޸�, ��üũ��, ����Ʈüũ�ƿ�
				+ " 0, ' ', ' ', "		//��Ż����, ī���, ī���ȣ
				+ " 1, ?, ?, ?)";	//����=1, �Խ�Ʈ�ѹ�, ��ѹ�, ����ѹ�
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			if(cVo.isIearlychi()) {
				System.out.println("��üũ�δ��Ⱦ���");
				pstmt.setInt(1, 0);
			} else {
				System.out.println("��üũ�ξȴ��Ⱦ���");
				pstmt.setInt(1, 1);
			}
			System.out.println("�Խ�Ʈ�ѹ� " +cVo.getGnumber());
			pstmt.setInt(2, Integer.parseInt(cVo.getGnumber()));
			System.out.println("��ѹ� "+cVo.getRnumber());
			pstmt.setInt(3, Integer.parseInt(cVo.getRnumber()));
			System.out.println("����ѹ� "+cVo.getBnumber());
			pstmt.setInt(4, Integer.parseInt(cVo.getBnumber()));
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
				System.out.println(666);
			} else {
				result = false;
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//üũ�� ����ϱ�
	
	
	//���ǹ�ȣ�� üũ������ ��������
	public CheckinVO getCheckininfobyRnum(String number) throws Exception {
		
		CheckinVO cVo = new CheckinVO();
		
		String sql = "select * from checkin where rnumber=? and istatus=1";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, number);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cVo.setInumber(rs.getString(1));
				cVo.setIcheckin(rs.getDate(2).toString());
				cVo.setIcheckout(rs.getDate(3).toString());
				cVo.setIroomsvc(rs.getString(4)+"");
				cVo.setIsvc(rs.getString(5)+"");
				cVo.setImemo(rs.getString(6)+"");
				if(rs.getInt(7)==0) {
					cVo.setIearlychi(true);
				} else {
					cVo.setIearlychi(false);
				}
				if(rs.getInt(8)==0) {
					cVo.setIlatecho(true);
				} else {
					cVo.setIlatecho(false);
				}
				cVo.setItotalpay(rs.getInt(9));
				cVo.setIcardcompany(rs.getString(10)+"");
				cVo.setIcardnumber(rs.getString(11)+"");
				cVo.setIstatus(rs.getInt(12));
				cVo.setGnumber(rs.getString(13));
				cVo.setRnumber(rs.getString(14));
				cVo.setBnumber(rs.getString(15));
			} else {
				cVo.setIcardcompany("0");
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return cVo;
	}//���ǹ�ȣ�� üũ������ ��������
	
	
	//üũ�ƿ���Ű��, �������������ϰ� istatus=2�� �ٲٱ�, roomstatus=0���� �ٲٱ�
	public boolean updateCheckoutstatus2(CheckinVO cVo) throws Exception {
		
		boolean result = false;
		
		String sql = "update checkin set iroomsvc=?, isvc=?, imemo=?, ilatecho=?, itotalpay=?, "
				+ "icardcompany=?, icardnumber=?, istatus=2 where inumber=? ";
		
		String roomsql = "update room set rstatus=0 where rnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmtroom = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, cVo.getIroomsvc());
			pstmt.setString(2, cVo.getIsvc());
			pstmt.setString(3, cVo.getImemo());
			if(cVo.isIlatecho()) {
				pstmt.setInt(4, 0);
			} else {
				pstmt.setInt(4, 1);
			}
			pstmt.setInt(5, cVo.getItotalpay());
			pstmt.setString(6, cVo.getIcardcompany());
			pstmt.setString(7, cVo.getIcardnumber());
			pstmt.setString(8, cVo.getInumber());
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
				System.out.println(333);
				pstmtroom = con.prepareStatement(roomsql);
				pstmtroom.setString(1, cVo.getRnumber());
				System.out.println(cVo.getRnumber());
				int j = pstmtroom.executeUpdate();
				if(j==1) {
					System.out.println("room status = 0 successful!");
				} else {
					System.out.println("room status update fail");
				}
			} else {
				result = false;
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmtroom!=null) {
					pstmt.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//üũ�ƿ���Ű��, �������������ϰ� istatus=2�� �ٲٱ�
	
	
	//üũ������ �������� 
	public boolean updateCheckininfo(CheckinVO cVo) throws Exception {
		boolean result = false;
		
		String sql = "update checkin set iroomsvc=?, isvc=?, imemo=?, itotalpay=? "
				+ " where inumber=? ";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			System.out.println(cVo.getIroomsvc());
			pstmt.setString(1, cVo.getIroomsvc()+" ");
			System.out.println(cVo.getIsvc());
			pstmt.setString(2, cVo.getIsvc()+" ");
			System.out.println(cVo.getImemo());
			pstmt.setString(3, cVo.getImemo()+" ");
			System.out.println(cVo.getItotalpay());
			pstmt.setInt(4, cVo.getItotalpay());
			pstmt.setString(5, cVo.getInumber());
			System.out.println(cVo.getInumber());
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
				System.out.println(134144);
			} else {
				result = false;
				System.out.println(555555);
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//üũ������ �������� 
	
	
	// ��month �� ����� ��������
	public int gettotaladdfeebyMonth(String month) throws Exception {
		int totalfee = 0;

		String sql = "select itotalpay from checkin where " 
				+ " to_char(icheckout,'mm')="+month+" and istatus=2";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				totalfee += rs.getInt(1);
			}

		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
			}
		}

		return totalfee;
	}// ��month �� ����� ��������

}
