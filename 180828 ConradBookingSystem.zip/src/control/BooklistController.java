package control;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import model.BookingVO;

public class BooklistController implements Initializable {
	@FXML private VBox vboxbooklist;
	@FXML private Button btnAll;
	@FXML private Button btnRenew;
	@FXML private Button btnExit;
	@FXML private Button btnCancel;
	@FXML private Button btnCheckin;
	@FXML private TableView<BookingVO> bookingtable = new TableView<>();	//TableView<BookingVO>
	//pdf����
	@FXML private Button btnSavefiledir;
	@FXML private TextField savefiledir;
	@FXML private Button btnPDF;
	private Stage primaryStage;

	//���̺�
	ObservableList<BookingVO> data = FXCollections.observableArrayList();
	
	//��ü���⸦ ��������?
	boolean totalcheck;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		//style setting
		vboxbooklist.setStyle("-fx-background-image: url('/images/booklistback.png');");
		btnAll.setStyle("-fx-base: #bdb286;");
		btnRenew.setStyle("-fx-base: #bdb286;");
		btnExit.setStyle("-fx-base: #bdb286;");
		btnCancel.setStyle("-fx-base: #bdb286;");
		btnCheckin.setStyle("-fx-base: #bdb286;");
		btnSavefiledir.setStyle("-fx-base: #bdb286;");
		btnPDF.setStyle("-fx-base: #bdb286;");
		
		//��ư����
		btnPDF.setDisable(true);
		
		//		
		try {
			BookingDAO bdao = new BookingDAO();
			bdao.updateStatus4byNoshow();
			System.out.println("�������� ����� ���� ����");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//���̺�����
		setBookingtable();
		
		//���� ����� �ҷ�����
		totalcheck=false;
		callTotalList();
		
		//��κ����ư
		btnAll.setOnAction(event->handlerBtnAllAction(event));
		//���ΰ�ħ��ư
		btnRenew.setOnAction(event->handlerBtnRenewAction(event));
		//��ҹ�ư
		btnCancel.setOnAction(event->handlerBtnCancelAction(event));
		//üũ�ι�ư
		btnCheckin.setOnAction(event->handlerBtnCheckinAction(event));
		
		//���ϰ�ι�ư
		btnSavefiledir.setOnAction(event->handlerBtnSavefiledirAction(event));
		//pdf���ϸ�����ư
		btnPDF.setOnAction(event->handlerBtnPDFAction(event));
		
		//�ݱ��ư
		btnExit.setOnAction(event->handlerBtnExitAction(event));
	}

	
	//�ݱ��ư
	public void handlerBtnExitAction(ActionEvent event) {
		Stage oldStage = (Stage) btnExit.getScene().getWindow();
        oldStage.close();
	}//�ݱ��ư


	//���ϰ�ι�ư
	public void handlerBtnSavefiledirAction(ActionEvent event) {
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File selectedDirectory = directoryChooser.showDialog(primaryStage);
		
		if(selectedDirectory!=null) {
			savefiledir.setText(selectedDirectory.getAbsolutePath());
			btnPDF.setDisable(false);
		}
	}//���ϰ�ι�ư


	//pdf���ϸ�����ư
	public void handlerBtnPDFAction(ActionEvent event) {
		String torf;
		String status;
		
		try {
			//pdf document ���� (rectangle pageSize, float marginleft, float marginright
			//					float margintop, float marginbottom )
			Document document = new Document(PageSize.A4, 0, 0, 30, 30);
			//pdf������ ������ ������ ����->pdf�����̻���->��Ʈ����������
			String strReportPDFName = "bookinglist_"+System.currentTimeMillis()+".pdf";
			PdfWriter.getInstance(document, new FileOutputStream(savefiledir.getText()+"\\"+strReportPDFName));
			//document�� ��� pdf������ �����ֵ����Ѵ�
			document.open();
			//�ѱ�������Ʈ����
			BaseFont bf = BaseFont.createFont("font/MALGUN.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			Font font = new Font(bf, 8, Font.NORMAL);
			Font font2 = new Font(bf, 14, Font.BOLD);
			//title
			Paragraph title = new Paragraph("���� ����Ʈ", font2);
			//�߰�����
			title.setAlignment(Element.ALIGN_CENTER);
			//������ �߰�
			document.add(title);
			document.add(new Paragraph("\r\n"));
			//������¥
			LocalDate date = LocalDate.now();
			Paragraph writeDay = new Paragraph(date.toString(), font);
			//����������
			writeDay.setAlignment(Element.ALIGN_RIGHT);
			//�������߰�
			document.add(writeDay);
			document.add(new Paragraph("\r\n"));
			
			//table����, �����ڿ� �÷����� ���ش�
			PdfPTable table = new PdfPTable(13);
			//������ �÷��� width�� ���Ѵ�
			table.setWidths(new int[] {50,80,80,80,30,70,30,30,30,30,40,60,50});
			
			//column title
			PdfPCell header1 = new PdfPCell(new Paragraph("�����ȣ", font));
			PdfPCell header2 = new PdfPCell(new Paragraph("�����ѳ�¥", font));
			PdfPCell header3 = new PdfPCell(new Paragraph("üũ�γ�¥", font));
			PdfPCell header4 = new PdfPCell(new Paragraph("üũ�ƿ���¥", font));
			PdfPCell header5 = new PdfPCell(new Paragraph("�����ο�", font));
			PdfPCell header6 = new PdfPCell(new Paragraph("�����ݾ�", font));
			PdfPCell header7 = new PdfPCell(new Paragraph("���Ŀ���", font));
			PdfPCell header8 = new PdfPCell(new Paragraph("������̿뿩��", font));
			PdfPCell header9 = new PdfPCell(new Paragraph("�ȳ��߿���", font));
			PdfPCell header10 = new PdfPCell(new Paragraph("��������", font));
			PdfPCell header11 = new PdfPCell(new Paragraph("�������", font));
			PdfPCell header12 = new PdfPCell(new Paragraph("������ȣ", font));
			PdfPCell header13 = new PdfPCell(new Paragraph("����ȣ��", font));
			
			//��������
			header1.setHorizontalAlignment(Element.ALIGN_CENTER);
			header2.setHorizontalAlignment(Element.ALIGN_CENTER);
			header3.setHorizontalAlignment(Element.ALIGN_CENTER);
			header4.setHorizontalAlignment(Element.ALIGN_CENTER);
			header5.setHorizontalAlignment(Element.ALIGN_CENTER);
			header6.setHorizontalAlignment(Element.ALIGN_CENTER);
			header7.setHorizontalAlignment(Element.ALIGN_CENTER);
			header8.setHorizontalAlignment(Element.ALIGN_CENTER);
			header9.setHorizontalAlignment(Element.ALIGN_CENTER);
			header10.setHorizontalAlignment(Element.ALIGN_CENTER);
			header11.setHorizontalAlignment(Element.ALIGN_CENTER);
			header12.setHorizontalAlignment(Element.ALIGN_CENTER);
			header13.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			//��������
			header1.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header2.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header8.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header9.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header10.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header11.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header12.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header13.setVerticalAlignment(Element.ALIGN_MIDDLE);
			
			//���̺����߰�
			table.addCell(header1);
			table.addCell(header2);
			table.addCell(header3);
			table.addCell(header4);
			table.addCell(header5);
			table.addCell(header6);
			table.addCell(header7);
			table.addCell(header8);
			table.addCell(header9);
			table.addCell(header10);
			table.addCell(header11);
			table.addCell(header12);
			table.addCell(header13);
			
			//db���� �� ����Ʈ ����
			BookingVO bVo = new BookingVO();
			BookingDAO bDao = new BookingDAO();
			ArrayList<BookingVO> list;
			if(totalcheck) {
				list = bDao.getBookingAllinfo();
			} else {
				list = bDao.getAffectiveBookinginfo();
			}
			
			int rowCount = list.size();
			
			PdfPCell cell1 = null;
			PdfPCell cell2 = null;
			PdfPCell cell3 = null;
			PdfPCell cell4 = null;
			PdfPCell cell5 = null;
			PdfPCell cell6 = null;
			PdfPCell cell7 = null;
			PdfPCell cell8 = null;
			PdfPCell cell9 = null;
			PdfPCell cell10 = null;
			PdfPCell cell11 = null;
			PdfPCell cell12 = null;
			PdfPCell cell13 = null;
			
			//
			for(int i=0 ; i<rowCount ; i++) {
				//
				bVo = list.get(i);
				
				cell1 = new PdfPCell(new Paragraph(bVo.getBnumber()+"",font));
				cell2 = new PdfPCell(new Paragraph(bVo.getBdate()+"",font));
				cell3 = new PdfPCell(new Paragraph(bVo.getBcheckin()+"",font));
				cell4 = new PdfPCell(new Paragraph(bVo.getBcheckout()+"",font));
				cell5 = new PdfPCell(new Paragraph(bVo.getBpeople()+"",font));
				cell6 = new PdfPCell(new Paragraph(bVo.getBpay()+"",font));
				//
				if(bVo.isBbreakfast()) {
					torf = "O";
				} else {
					torf = "X";
				}
				cell7 = new PdfPCell(new Paragraph(torf,font));
				if(bVo.isBlounge()) {
					torf = "O";
				} else {
					torf = "X";
				}
				cell8 = new PdfPCell(new Paragraph(torf,font));
				if(bVo.isBguidedog()) {
					torf = "O";
				} else {
					torf = "X";
				}
				cell9 = new PdfPCell(new Paragraph(torf,font));
				if(bVo.isBparking()) {
					torf = "O";
				} else {
					torf = "X";
				}
				cell10 = new PdfPCell(new Paragraph(torf,font));
				//
				switch(bVo.getBstatus()) {
				case 0 :	//��������
					status = "error";
					break;
				case 1 :
					status = "������";
					break;
				case 2 :
					status = "üũ�ε�";
					break;
				case 3 :
				case 4 :
				case 5 :
					status = "������ҵ�";
				default :
					status = "null";
					break;
				}
				cell11 = new PdfPCell(new Paragraph(status,font));
				cell12 = new PdfPCell(new Paragraph(bVo.getGnumber()+"",font));
				cell13 = new PdfPCell(new Paragraph(bVo.getRnumber()+"",font));
						
				//��������
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				
				//��������
				cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				//table�� �� �߰�
				table.addCell(cell1);
				table.addCell(cell2);
				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);
				
			}//for����
			
			//������ ���̺� �߰�
			document.add(table);
			document.add(new Paragraph("\r\n"));
			
			
			//������ �ݴ´�
			document.close();
			
			savefiledir.clear();
			btnPDF.setDisable(true);
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("PDF ���� ����");
			alert.setHeaderText("PDF������ �����Ͽ����ϴ�");
			alert.setContentText("�����մϴ�");
			alert.showAndWait();
			
		} catch ( FileNotFoundException se ) {
			se.printStackTrace();
		} catch ( DocumentException se ) {
			se.printStackTrace();
		} catch ( IOException se ) {
			se.printStackTrace();
		}
		
	}//pdf���ϸ�����ư


	//��� ���� �� ��������
	public void handlerBtnAllAction(ActionEvent event) {
		
		data.removeAll(data);
		
		BookingVO bVo = null;
		BookingDAO bDao = new BookingDAO();
		ArrayList<BookingVO> list = null;
		
		list = bDao.getBookingAllinfo();
		int rc = list.size();
		
		for(int i=0 ; i<rc ; i++) {
			bVo = list.get(i);
			data.add(bVo);
		}
		
		totalcheck = true;
	}//��� ���� �� ��������


	//��ҹ�ư
	public void handlerBtnCancelAction(ActionEvent event) {
		//b_status�� 3���� �ٲٴ� �۾�
		BookingDAO bDao = new BookingDAO();
		BookingVO bVo = null;
		boolean result = false;
		
		bVo = bookingtable.getSelectionModel().getSelectedItem();
		
		try {
			result = bDao.cancelBooking(bVo.getBnumber());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(result) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("���� ���");
			alert.setHeaderText("������ ����Ͽ����ϴ�");
			alert.setContentText("������ ����Ͽ����ϴ�");
			alert.showAndWait();
			//
			data.removeAll(data);
			callTotalList();
		} else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� ��� ����");
			alert.setHeaderText("������ ������� ���߽��ϴ�");
			alert.setContentText("�ٽ� �õ��غ�����");
			alert.showAndWait();
		}
		
		
	}//��ҹ�ư


	//üũ�ι�ư
	public void handlerBtnCheckinAction(ActionEvent event) {
		try {

			Parent checkin = FXMLLoader.load(getClass().getResource("/view/checkin.fxml"));
			Scene newScene = new Scene(checkin);
			Stage primaryStage = new Stage();
			primaryStage.setTitle("üũ��");
			primaryStage.setScene(newScene);
			primaryStage.setResizable(false);
			Stage oldStage = (Stage)btnCheckin.getScene().getWindow();
			oldStage.close();
			primaryStage.show();
			
			BookingVO booking = bookingtable.getSelectionModel().getSelectedItem();
			
			TextField bookname = (TextField) checkin.lookup("#txtBookname");
			ComboBox<String> booknum = (ComboBox<String>) checkin.lookup("#cbBooklist");
			TextField faname = (TextField) checkin.lookup("#txtFamilyname");
			TextField finame = (TextField) checkin.lookup("#txtFirstname");
			Button fsearch = (Button) checkin.lookup("#btnSearch");
			
			booknum.setValue(booking.getBnumber());
			bookname.setText(booking.getBnumber());
			
			bookname.setEditable(false);
			faname.setDisable(true);
			finame.setDisable(true);
			fsearch.setDisable(true);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}//üũ�ι�ư


	//���ΰ�ħ��ư
	public void handlerBtnRenewAction(ActionEvent event) {
		data.removeAll(data);
		//��ü����Ǻҷ�����
		callTotalList();
		totalcheck=false;
	}//���ΰ�ħ��ư


	//��ü ����� �ҷ�����
	public void callTotalList() {
		
		BookingVO bVo = new BookingVO();
		BookingDAO bDao = new BookingDAO();
		ArrayList<BookingVO> list ;
		
		
		list = bDao.getAffectiveBookinginfo();
		int rc = list.size();
		
		for(int i=0 ; i<rc ; i++) {
			bVo = list.get(i);
			data.add(bVo);
		}
	}//��ü ����� �ҷ�����


	//���̺�����
	public void setBookingtable() {
		
		bookingtable.setEditable(false);
		
		TableColumn colbNumber = new TableColumn("�����ȣ");
		colbNumber.setMinWidth(70);
		colbNumber.setStyle("-fx-alignment:CENTER");
		colbNumber.setCellValueFactory(new PropertyValueFactory<>("bnumber"));
		
		TableColumn colbDate = new TableColumn("�����ѳ�¥");
		colbDate.setMinWidth(95);
		colbDate.setStyle("-fx-alignment:CENTER");
		colbDate.setCellValueFactory(new PropertyValueFactory<>("bdate"));
		
		TableColumn colbCheckin = new TableColumn("üũ�γ�¥");
		colbCheckin.setMinWidth(95);
		colbCheckin.setStyle("-fx-alignment:CENTER");
		colbCheckin.setCellValueFactory(new PropertyValueFactory<>("bcheckin"));
		
		TableColumn colbCheckout = new TableColumn("üũ�ƿ���¥");
		colbCheckout.setMinWidth(95);
		colbCheckout.setStyle("-fx-alignment:CENTER");
		colbCheckout.setCellValueFactory(new PropertyValueFactory<>("bcheckout"));
		
		TableColumn colbPeople = new TableColumn("�����ο�");
		colbPeople.setMinWidth(70);
		colbPeople.setStyle("-fx-alignment: CENTER");
		colbPeople.setCellValueFactory(new PropertyValueFactory<>("bpeople"));
		
		TableColumn colbPay = new TableColumn("�����ݾ�");
		colbPay.setMinWidth(70);
		colbPay.setStyle("-fx-alignment: CENTER");
		colbPay.setCellValueFactory(new PropertyValueFactory<>("bpay"));
		
		TableColumn colbBreakfast = new TableColumn("����");
		colbBreakfast.setMinWidth(60);
		colbBreakfast.setStyle("-fx-alignment: CENTER");
		colbBreakfast.setCellValueFactory(new PropertyValueFactory<>("bbreakfast"));
		
		TableColumn colbLounge = new TableColumn("�����");
		colbLounge.setMinWidth(60);
		colbLounge.setStyle("-fx-alignment: CENTER");
		colbLounge.setCellValueFactory(new PropertyValueFactory<>("blounge"));
		
		TableColumn colbGuidedog = new TableColumn("�ȳ���");
		colbGuidedog.setMinWidth(60);
		colbGuidedog.setStyle("-fx-alignment:CENTER");
		colbGuidedog.setCellValueFactory(new PropertyValueFactory<>("bguidedog"));
		
		TableColumn colbParking = new TableColumn("����");
		colbParking.setMinWidth(60);
		colbParking.setStyle("-fx-alignment:CENTER");
		colbParking.setCellValueFactory(new PropertyValueFactory<>("bparking"));
		
		TableColumn colbCardcompany = new TableColumn("ī���");
		colbCardcompany.setMinWidth(70);
		colbCardcompany.setStyle("-fx-alignment:CENTER");
		colbCardcompany.setCellValueFactory(new PropertyValueFactory<>("bcardcompany"));
		
		TableColumn colgNumber = new TableColumn("������ȣ");
		colgNumber.setMinWidth(85);
		colgNumber.setStyle("-fx-alignment:CENTER");
		colgNumber.setCellValueFactory(new PropertyValueFactory<>("gnumber"));
		
		TableColumn colrNumber = new TableColumn("����ȣ��");
		colrNumber.setMinWidth(70);
		colrNumber.setStyle("-fx-alignment:CENTER");
		colrNumber.setCellValueFactory(new PropertyValueFactory<>("rnumber"));

		bookingtable.getColumns().addAll(colbNumber, colbDate, colbCheckin, colbCheckout, 
				colbPeople, colbPay, colbBreakfast, colbLounge, colbGuidedog, colbParking, 
				colbCardcompany, colgNumber, colrNumber);
		
		bookingtable.setItems(data);
		
	}//���̺�����

}
