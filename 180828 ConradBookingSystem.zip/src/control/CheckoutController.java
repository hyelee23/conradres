package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.CheckinVO;
import model.GuestVO;

public class CheckoutController implements Initializable {
	@FXML private VBox vboxcheckout;
	@FXML private TextField txtRoomnum;
	@FXML private Button btnSearch;
	@FXML private TextField txtFamilyname;
	@FXML private TextField txtFirstname;
	@FXML private TextField txtGuestnum;
	@FXML private TextField txtMemebershipnum;
	@FXML private Label txtInumber;
	@FXML private Label txtEarlychi;
	@FXML private TextArea txtRoomsvc;
	@FXML private TextArea txtSvc;
	@FXML private TextArea txtMemo;
	@FXML private CheckBox chbLatecho;
	@FXML private TextField txtTotalpay;
	@FXML private ComboBox<String> cbCardcompany;
	@FXML private TextField txtCardnum1;
	@FXML private TextField txtCardnum2;
	@FXML private TextField txtCardnum3;
	@FXML private TextField txtCardnum4;
	@FXML private Button btnCardpay;
	@FXML private Button btnSave;
	@FXML private Button btnExit;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//style setting
		vboxcheckout.setStyle("-fx-background-image: url('/images/checkoutback.png');");
		btnSearch.setStyle("-fx-base: #bdb286;");
		chbLatecho.setStyle("-fx-base: #bdb286;");
		cbCardcompany.setStyle("-fx-base: #e6debf;");
		btnCardpay.setStyle("-fx-base: #bdb286;");
		btnSave.setStyle("-fx-base: #bdb286;");
		btnExit.setStyle("-fx-base: #bdb286;");
		
		//�ʱ��ư�ʵ弳��
		txtFamilyname.setDisable(true);
		txtFirstname.setDisable(true);
		txtGuestnum.setDisable(true);
		txtMemebershipnum.setDisable(true);
		txtInumber.setVisible(false);
		txtRoomsvc.setDisable(true);
		txtSvc.setDisable(true);
		txtMemo.setDisable(true);
		chbLatecho.setVisible(true);//g...
		txtTotalpay.setDisable(true);
		cbCardcompany.setDisable(true);
		txtCardnum1.setDisable(true);
		txtCardnum2.setDisable(true);
		txtCardnum3.setDisable(true);
		txtCardnum4.setDisable(true);
		btnCardpay.setDisable(true);
		btnSave.setDisable(true);
		
		//ī��缼��
		cbCardcompany.setItems(FXCollections.observableArrayList("��ī��", "�Ｚī��", "����ī��", "�츮ī��", "����ī��", "��Ÿī��"));
		
		//�˻���ư
		btnSearch.setOnAction(event->handlerBtnSearchAction(event));
		//ī�������ư
		btnCardpay.setOnAction(event->handlerBtnCardpayAction(event));
		//�����ư
		btnSave.setOnAction(event->handlerBtnSaveAction(event));
		//�ݱ��ư
		btnExit.setOnAction(event->handlerBtnExitAction(event));
		
	}

	
	//���ǹ�ȣ�� üũ������ �˻���ư
	public void handlerBtnSearchAction(ActionEvent event) {
		
		CheckinVO cVo = null;
		CheckinDAO cDao = new CheckinDAO();
		
		RoomDAO rDao = new RoomDAO();
		
		GuestVO gVo = new GuestVO();
		GuestDAO gDao = new GuestDAO();
		
		int price = 0;
		
		if(txtRoomnum.getText().equals("")) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� üũ�� ���� �˻�");
			alert.setHeaderText("���� ȣ���� �Է��ϼ���");
			alert.setContentText("�ٽ� �ѹ� Ȯ���ϼ���");
			alert.showAndWait();
		} else {
			try {
				cVo = cDao.getCheckininfobyRnum(txtRoomnum.getText().trim());
				price = cVo.getItotalpay();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			if(cVo.getIcardcompany().equals("0")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� üũ�� ���� �˻�");
				alert.setHeaderText("���� ��ȣ ����");
				alert.setContentText("���� ȣ���� �ٽ� Ȯ���ϼ���");
				alert.showAndWait();
			} else {
				//�ʵ弼��
				try {
					gVo=gDao.searchGuestinfo(cVo.getGnumber());
					txtFamilyname.setText(gVo.getGfamilyname());
					txtFirstname.setText(gVo.getGfirstname());
					txtMemebershipnum.setText(gVo.getGmembershipnum());
				} catch (Exception e) {
					e.printStackTrace();
				}
				txtInumber.setText(cVo.getInumber());
				txtGuestnum.setText(cVo.getGnumber());
				if(cVo.isIearlychi()) {
					txtEarlychi.setText("Y");
					try {
						price += rDao.searchpaymentbyRnum(cVo.getRnumber()) /2;
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					txtEarlychi.setText("N");
				}
				txtRoomsvc.setText(cVo.getIroomsvc());
				txtSvc.setText(cVo.getIsvc());
				txtMemo.setText(cVo.getImemo());
				if(cVo.isIlatecho()) {
					chbLatecho.setSelected(true);
					try {
						price += rDao.searchpaymentbyRnum(cVo.getRnumber()) /2;
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					chbLatecho.setSelected(false);
				}
				txtTotalpay.setText(cVo.getItotalpay()+"");
				
				//�ʵ弳��
				txtFamilyname.setDisable(false);
				txtFamilyname.setEditable(false);
				txtFirstname.setDisable(false);
				txtFirstname.setEditable(false);
				txtGuestnum.setDisable(false);
				txtGuestnum.setEditable(false);
				txtMemebershipnum.setDisable(false);
				txtMemebershipnum.setEditable(false);
				//
				txtRoomsvc.setDisable(false);
				txtSvc.setDisable(false);
				txtMemo.setDisable(false);
				chbLatecho.setVisible(true);
				txtTotalpay.setDisable(false);
				cbCardcompany.setDisable(false);
				txtCardnum1.setDisable(false);
				txtCardnum2.setDisable(false);
				txtCardnum3.setDisable(false);
				txtCardnum4.setDisable(false);
				btnCardpay.setDisable(false);
				btnSave.setDisable(false);
			}
		}
		
	}//���ǹ�ȣ�� üũ������ �˻���ư


	//ī�������ư
	public void handlerBtnCardpayAction(ActionEvent event) {
		
		if(cbCardcompany.getValue().isEmpty() ||
				txtCardnum1.getText().equals("") || txtCardnum2.getText().equals("") ||
				txtCardnum3.getText().equals("") || txtCardnum4.getText().equals("") ) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ī�� ���� ����");
			alert.setHeaderText("ī���ȣ ��ȣ ����");
			alert.setContentText("ī���ȣ�� �ٽ� Ȯ���ϼ���");
			alert.showAndWait();
		} else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("üũ�ƿ� ī�� ����");
			alert.setHeaderText("ī������� �Ϸ�Ǿ����ϴ�");
			alert.setContentText("�����մϴ�");
			alert.showAndWait();
		}
	}//ī�������ư


	//�����ư
	public void handlerBtnSaveAction(ActionEvent event) {
		System.out.println(11111111+"?");
		boolean result = false;
		
		CheckinVO cVo = new CheckinVO();
		CheckinDAO cDao = new CheckinDAO();
		GuestVO gVo = new GuestVO();
		GuestDAO gDao = new GuestDAO();
		
		if(txtRoomnum.getText().equals("")) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("üũ�ƿ� ����");
			alert.setHeaderText("���ǹ�ȣ�� �Է��ϼ���");
			alert.setContentText("�ٽ� �õ��غ�����");
			alert.showAndWait();
		} else {
			cVo.setInumber(txtInumber.getText());
			cVo.setIroomsvc(txtRoomsvc.getText());
			cVo.setIsvc(txtSvc.getText());
			cVo.setImemo(txtMemo.getText());
			if(chbLatecho.isSelected()) {
				cVo.setIlatecho(true);
			} else {
				cVo.setIlatecho(false);
			}
			cVo.setItotalpay(Integer.parseInt(txtTotalpay.getText()));
			cVo.setIcardcompany(cbCardcompany.getValue().toString());
			cVo.setIcardnumber(txtCardnum1.getText()+txtCardnum2.getText()+
					txtCardnum3.getText()+txtCardnum4.getText());
			cVo.setRnumber(txtRoomnum.getText());
			
			try {
				result = cDao.updateCheckoutstatus2(cVo);
				System.out.println("updatecheckoutstatus2 + "+result);
				gVo = gDao.searchGuestinfobyMS(txtMemebershipnum.getText());
				int point = Integer.parseInt(txtTotalpay.getText())/20;
				System.out.println(point);
				boolean xo = gDao.updateMSpoint(txtMemebershipnum.getText(), point);
				if(xo) {
					System.out.println("����Ʈ��������");
				} else {
					System.out.println("����Ʈ��������");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			if(result) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("üũ�ƿ� �Ϸ�");
				alert.setHeaderText("üũ�ƿ� �Ǿ����ϴ�");
				alert.setContentText("�����մϴ�");
				alert.showAndWait();
				
				//�ʵ�Ŭ����
				txtRoomnum.clear();
				txtFamilyname.clear();
				txtFirstname.clear();
				txtGuestnum.clear();
				txtMemebershipnum.clear();
				txtInumber.setText("");
				txtEarlychi.setText("");
				txtRoomsvc.clear();
				txtSvc.clear();
				txtMemo.clear();
				chbLatecho.setSelected(false);
				txtTotalpay.clear();
				cbCardcompany.setItems(FXCollections.observableArrayList("��ī��", "�Ｚī��", "����ī��", "�츮ī��", "����ī��", "��Ÿī��"));
				txtCardnum1.clear();
				txtCardnum2.clear();
				txtCardnum3.clear();
				txtCardnum4.clear();
				//�ʱ��ư�ʵ弳��
				txtFamilyname.setDisable(true);
				txtFirstname.setDisable(true);
				txtGuestnum.setDisable(true);
				txtMemebershipnum.setDisable(true);
				txtInumber.setVisible(false);
				txtRoomsvc.setDisable(true);
				txtSvc.setDisable(true);
				txtMemo.setDisable(true);
				chbLatecho.setVisible(true);//g...
				txtTotalpay.setDisable(true);
				cbCardcompany.setDisable(true);
				txtCardnum1.setDisable(true);
				txtCardnum2.setDisable(true);
				txtCardnum3.setDisable(true);
				txtCardnum4.setDisable(true);
				btnCardpay.setDisable(true);
				btnSave.setDisable(true);
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("üũ�ƿ� ����");
				alert.setHeaderText("üũ�ƿ��� ������ ������ϴ�");
				alert.setContentText("�ٽ� �õ��غ�����");
				alert.showAndWait();
			}
		}
		
	}//�����ư
	

	//�ݱ��ư
	public void handlerBtnExitAction(ActionEvent event) {
		Stage oldStage = (Stage) btnExit.getScene().getWindow();
        oldStage.close();
	}//�ݱ��ư

}
