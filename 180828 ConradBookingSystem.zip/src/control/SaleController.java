package control;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SaleController implements Initializable {
	@FXML private VBox vboxsale;
	@FXML private Button btnExit;
	@FXML private BarChart saleChart;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		//style setting
		vboxsale.setStyle("-fx-background-image: url('/images/saleback.png');");
		btnExit.setStyle("-fx-base: #bdb286;");
		
		//����Ʈ����
		settingbarchart();
		
		//�ݱ��ư
		btnExit.setOnAction(event->handlerBtnExitAction(event));
		
	}

	
	//����Ʈ����
	public void settingbarchart() {
		BookingDAO bdao = new BookingDAO();
		CheckinDAO cdao = new CheckinDAO();
		
		LocalDate today = LocalDate.now();
		LocalDate cctoday;
		String month;
		
		int thismonthBF=0;
		int thismonthAF=0;
		int lastmonthBF=0;
		int lastmonthAF=0;
		int twomonthagoBF=0;
		int twomonthagoAF=0;

		try {
			month = today.getMonthValue()+"";
			thismonthBF = bdao.gettotalbookingfeebyMonth(month);
			thismonthAF = cdao.gettotaladdfeebyMonth(month);
			
			cctoday = today.minusMonths(1);
			month = cctoday.getMonthValue()+"";
			lastmonthBF = bdao.gettotalbookingfeebyMonth(month);
			lastmonthAF = cdao.gettotaladdfeebyMonth(month);
			
			cctoday = today.minusMonths(2);
			month = cctoday.getMonthValue()+"";
			twomonthagoBF = bdao.gettotalbookingfeebyMonth(month);
			twomonthagoAF = cdao.gettotaladdfeebyMonth(month);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		//����� ����
		XYChart.Series seriesBookingfee = new XYChart.Series();
		seriesBookingfee.setName("����� ����");
		ObservableList bookingfeeList = FXCollections.observableArrayList();
		month = today.getMonth()+"";
		bookingfeeList.add(new XYChart.Data(month, thismonthBF));
		cctoday = today.minusMonths(1);
		month = cctoday.getMonth()+"";
		bookingfeeList.add(new XYChart.Data(month, lastmonthBF));
		cctoday = today.minusMonths(2);
		month = cctoday.getMonth()+"";
		bookingfeeList.add(new XYChart.Data(month, twomonthagoBF));
		seriesBookingfee.setData(bookingfeeList);
		saleChart.getData().add(seriesBookingfee);
		
		//üũ�ƿ� �߰��� ����
		XYChart.Series seriesAddfee = new XYChart.Series();
		seriesAddfee.setName("�߰��� ����");
		ObservableList addfeeList = FXCollections.observableArrayList();
		month = today.getMonth() + "";
		addfeeList.add(new XYChart.Data(month, thismonthAF));
		cctoday = today.minusMonths(1);
		month = cctoday.getMonth() + "";
		addfeeList.add(new XYChart.Data(month, lastmonthAF));
		cctoday = today.minusMonths(2);
		month = cctoday.getMonth() + "";
		addfeeList.add(new XYChart.Data(month, twomonthagoAF));
		seriesAddfee.setData(addfeeList);
		saleChart.getData().add(seriesAddfee);
		
		//�Ѹ���
		XYChart.Series seriesTotalfee = new XYChart.Series();
		seriesTotalfee.setName("�� ����");
		ObservableList totalfeeList = FXCollections.observableArrayList();
		month = today.getMonth() + "";
		totalfeeList.add(new XYChart.Data(month, thismonthBF+thismonthAF));
		cctoday = today.minusMonths(1);
		month = cctoday.getMonth() + "";
		totalfeeList.add(new XYChart.Data(month, lastmonthBF+lastmonthAF));
		cctoday = today.minusMonths(2);
		month = cctoday.getMonth() + "";
		totalfeeList.add(new XYChart.Data(month, twomonthagoBF+twomonthagoAF));
		seriesTotalfee.setData(totalfeeList);
		saleChart.getData().add(seriesTotalfee);
		
	}//����Ʈ����
	

	//�ݱ��ư
	public void handlerBtnExitAction(ActionEvent event) {
		Stage oldStage = (Stage) btnExit.getScene().getWindow();
        oldStage.close();
	}//�ݱ��ư

}
