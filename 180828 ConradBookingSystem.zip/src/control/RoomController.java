package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.CheckinVO;

public class RoomController implements Initializable {
	@FXML private VBox vboxroom;
	@FXML private Label txtinumber;
	@FXML private Label txtRoomnumber;
	@FXML private ImageView imgRoom;
	@FXML private Label txtRoomname;
	@FXML private Label txtoptbed;
	@FXML private Label txtoptgrade;
	@FXML private Label txtoptview;
	@FXML private Label txtoptdog;
	@FXML private TextField txtGuestnum;
	@FXML private Button btnGuest;
	@FXML private TextField txtCheckin;
	@FXML private TextField txtCheckout;
	@FXML private TextArea txtRoomsvc;
	@FXML private TextArea txtSvc;
	@FXML private TextArea txtMemo;
	@FXML private TextField txtAdditionalfee;
	@FXML private Button btnSave;
	@FXML private Button btnExit;
	@FXML private Button btnCheckout;
	
	CheckinVO thisroom = new CheckinVO();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//style setting
		vboxroom.setStyle("-fx-background-image: url('/images/roomback.png');");
		btnGuest.setStyle("-fx-base: #bdb286;");
		btnSave.setStyle("-fx-base: #bdb286;");
		btnExit.setStyle("-fx-base: #bdb286;");
		btnCheckout.setStyle("-fx-base: #bdb286;");
		
		//
		txtinumber.setVisible(false);
		
		//�������������ư
		btnGuest.setOnAction(event->handlerBtnGuestAction(event));
		//���������ư
		btnSave.setOnAction(event->handlerBtnSaveAction(event));
		//�ݱ��ư
		btnExit.setOnAction(event->handlerBtnExitAction(event));
		//üũ�ƿ���ư
		btnCheckout.setOnAction(event->hanlderBtnCheckoutAction(event));
		
	}

	
	//�������������ư
	public void handlerBtnGuestAction(ActionEvent event) {
		
		try {
			
			Parent guest = FXMLLoader.load(getClass().getResource("/view/guest.fxml"));
			Scene newScene = new Scene(guest);
			Stage primaryStage = new Stage();
			primaryStage.setTitle("��������");
			primaryStage.setScene(newScene);
			primaryStage.setResizable(false);
			Stage oldStage = (Stage) btnGuest.getScene().getWindow();
			oldStage.close();
			primaryStage.show();
			
			TextField guestnum = (TextField) guest.lookup("#txtGuestnum");
			guestnum.setText(txtGuestnum.getText());
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}//�������������ư


	//���������ư
	public void handlerBtnSaveAction(ActionEvent event) {
		boolean result = false;
		CheckinVO cVo = new CheckinVO();
		CheckinDAO cDao = new CheckinDAO();
		
		cVo.setInumber(txtRoomnumber.getText());
		cVo.setIroomsvc(txtRoomsvc.getText());
		cVo.setIsvc(txtSvc.getText());
		cVo.setImemo(txtMemo.getText());
		cVo.setItotalpay(Integer.parseInt(txtAdditionalfee.getText()));
		cVo.setInumber(txtinumber.getText());
		
		try {
			result = cDao.updateCheckininfo(cVo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(result) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("üũ�� ���� ����");
			alert.setHeaderText("üũ�� ���� ������ �Ϸ��߽��ϴ�");
			alert.setContentText("üũ�������� �����߽��ϴ�");
			alert.showAndWait();
		} else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("üũ�� ���� ����");
			alert.setHeaderText("üũ�� ���� ������ �����߽��ϴ�");
			alert.setContentText("�ٽ� �õ��غ�����");
			alert.showAndWait();
		}
		
	}//���������ư


	//�ݱ��ư
	public void handlerBtnExitAction(ActionEvent event) {
		Stage oldStage = (Stage) btnExit.getScene().getWindow();
        oldStage.close();
	}//�ݱ��ư


	//üũ�ƿ���ư
	public void hanlderBtnCheckoutAction(ActionEvent event) {
		
		try {
			
			Parent guest = FXMLLoader.load(getClass().getResource("/view/checkout.fxml"));
			Scene newScene = new Scene(guest);
			Stage primaryStage = new Stage();
			primaryStage.setTitle("������Ȳ");
			primaryStage.setScene(newScene);
			primaryStage.setResizable(false);
			Stage oldStage = (Stage) btnCheckout.getScene().getWindow();
			oldStage.close();
			primaryStage.show();
			
			TextField roomnum = (TextField) guest.lookup("#txtRoomnum");
			roomnum.setText(txtRoomnumber.getText());
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}//üũ�ƿ���ư

}
