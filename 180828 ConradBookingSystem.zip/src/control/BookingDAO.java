package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import model.BookingVO;
import model.RoomVO;


public class BookingDAO {
	
	//üũ�γ�¥, üũ�ƿ���¥, �ȳ��߿��η� ������ ���� ã��
	public ArrayList<RoomVO> searchbookingRoom(String chi, String cho, int people, boolean dog, boolean breakfast, boolean lounge) {
		
		ArrayList<RoomVO> list = new ArrayList<RoomVO>();
		RoomVO rVo;
		RoomDAO rdao = new RoomDAO();
		String number;
			
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select rnumber from room minus " + 
				"( select rnumber from booking " + 
				" where bcheckin between to_date('"+chi+"','YYYY-MM-DD') and to_date('"+cho+"','YYYY-MM-DD') " + 
				" union " + 
				" select rnumber from booking " + 
				" where bcheckout between to_date('"+chi+"','YYYY-MM-DD') and to_date('"+cho+"','YYYY-MM-DD') " + 
				")" + 
				" intersect " + 
				" select rnumber from room minus " + 
				"( select rnumber from checkin " + 
				" where icheckin between to_date('"+chi+"','YYYY-MM-DD') and to_date('"+cho+"','YYYY-MM-DD') " + 
				" union " + 
				" select rnumber from checkin " + 
				" where icheckout between to_date('"+chi+"','YYYY-MM-DD') and to_date('"+cho+"','YYYY-MM-DD') " + 
				")";
		

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				number = rs.getString(1);
				
				rVo = rdao.searchRoominfo(number);
				
				//������ ����free����(status==1) , �ȳ��߿��θ� Ȯ���ϱ�
				if(rVo.getRstatus()==0 && rVo.isRguidedog()==dog) {	//8�� ���߿� 0���� �ٲٱ�
					int original = rVo.getRprice();
					
					if(breakfast && lounge) {
						rVo.setRprice(original+(60000*people));
					} else if (breakfast) {
						rVo.setRprice(original+(40000*people));
					} else if (lounge) {
						rVo.setRprice(original+(30000*people));
					} else {
						rVo.setRprice(original);
					}
					
					list.add(rVo);
				}//if������
			}//while������
			
		} catch (SQLException ee) {
			System.out.println(ee);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return list;
	}//üũ�γ�¥, üũ�ƿ���¥, �ȳ��߿��η� ������ ���� ã��
	
	
	//���̺��� �Ѹ� ��Ÿ������ ��������, ���̸�, �氡�� --�Ⱦ��¸޼ҵ尰��
	public ArrayList<String> getColumnName() {
		ArrayList<String> cn = new ArrayList<String>();
		
		String sql = "select rname, rprice from room";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		//metadata
		ResultSetMetaData rsmd = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			
			int cols = rsmd.getColumnCount();
			for(int i=1 ; i<=cols ; i++) {
				cn.add(rsmd.getColumnName(i));
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return cn;
	}//���̺��� �Ѹ� ��Ÿ������ ��������, ���̸�, �氡��
	
	
	//�����ϱ�
	public boolean insertBookinginfo(BookingVO bVo) throws Exception {
		boolean result = false;
		String chi = bVo.getBcheckin();
		String cho = bVo.getBcheckout();
		
		String sql = "insert into booking values (booking_seq.nextval, sysdate, "
				+ "to_date('"+chi+"','YYYY-MM-DD'), to_date('"+cho+"','YYYY-MM-DD'), "
				+ "?, ?, ?, ?, ?, ?, "	//���,�ݾ� , ����,�����,��,����
				+ "?, ?, ?, ?, ?)";		//ī���,ī���ȣ , ����=1 , ������ȣ,���ǹ�ȣ
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bVo.getBpeople());
			pstmt.setInt(2, bVo.getBpay());
			if(bVo.isBbreakfast()) {
				pstmt.setInt(3, 0);
			} else {
				pstmt.setInt(3, 1);
			}
			if(bVo.isBlounge()) {
				pstmt.setInt(4, 0);
			} else {
				pstmt.setInt(4, 1);
			}
			if(bVo.isBguidedog()) {
				pstmt.setInt(5, 0);
			} else {
				pstmt.setInt(5, 1);
			}
			if(bVo.isBparking()) {
				pstmt.setInt(6, 0);
			} else {
				pstmt.setInt(6, 1);
			}
			pstmt.setString(7, bVo.getBcardcompany());
			pstmt.setString(8, bVo.getBcardnumber());
			pstmt.setInt(9, 1);	//1�� ������ ����
			pstmt.setInt(10, Integer.parseInt(bVo.getGnumber()));
			pstmt.setInt(11, Integer.parseInt(bVo.getRnumber()));
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
			} else {
				result = false;
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//�����ϱ�
	
	
	//��� ����� �ҷ�����
	public ArrayList<BookingVO> getBookingAllinfo() {
		ArrayList<BookingVO> list = new ArrayList<BookingVO>();
		BookingVO bVo = new BookingVO();
		
		String sql = "select * from booking where bnumber <> 2";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				bVo = new BookingVO();
				bVo.setBnumber(rs.getString(1));
				bVo.setBdate(rs.getDate(2).toString());
				bVo.setBcheckin(rs.getDate(3).toString());
				bVo.setBcheckout(rs.getDate(4).toString());
				bVo.setBpeople(rs.getInt(5));
				bVo.setBpay(rs.getInt(6));
				if(rs.getInt(7)==0) {
					bVo.setBbreakfast(true);
				} else {
					bVo.setBbreakfast(false);
				}
				if(rs.getInt(8)==0) {
					bVo.setBlounge(true);
				} else {
					bVo.setBlounge(false);
				}
				if(rs.getInt(9)==0) {
					bVo.setBguidedog(true);
				} else {
					bVo.setBguidedog(false);
				}
				if(rs.getInt(10)==0) {
					bVo.setBparking(true);
				} else {
					bVo.setBparking(false);
				}
				bVo.setBcardcompany(rs.getString(11));
				bVo.setBcardnumber(rs.getString(12));
				bVo.setBstatus(rs.getInt(13));
				bVo.setGnumber(rs.getString(14));
				bVo.setRnumber(rs.getString(15));
				
				list.add(bVo);
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return list;
	}//��� ����� �ҷ�����
	
	
	//��� ��ȿ�� ����� �ҷ�����
		public ArrayList<BookingVO> getAffectiveBookinginfo() {
			ArrayList<BookingVO> list = new ArrayList<BookingVO>();
			BookingVO bVo;
			
			String sql = "select * from booking where bstatus=1 and bnumber<>2";
			
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try {
				con = DBUtil.getConnection();
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					bVo = new BookingVO();
					bVo.setBnumber(rs.getString(1));
					bVo.setBdate(rs.getDate(2).toString());
					bVo.setBcheckin(rs.getDate(3).toString());
					bVo.setBcheckout(rs.getDate(4).toString());
					bVo.setBpeople(rs.getInt(5));
					bVo.setBpay(rs.getInt(6));
					if(rs.getInt(7)==0) {
						bVo.setBbreakfast(true);
					} else {
						bVo.setBbreakfast(false);
					}
					if(rs.getInt(8)==0) {
						bVo.setBlounge(true);
					} else {
						bVo.setBlounge(false);
					}
					if(rs.getInt(9)==0) {
						bVo.setBguidedog(true);
					} else {
						bVo.setBguidedog(false);
					}
					if(rs.getInt(10)==0) {
						bVo.setBparking(true);
					} else {
						bVo.setBparking(false);
					}
					bVo.setBcardcompany(rs.getString(11));
					bVo.setBcardnumber(rs.getString(12));
					bVo.setBstatus(rs.getInt(13));
					bVo.setGnumber(rs.getString(14));
					bVo.setRnumber(rs.getString(15));
					
					list.add(bVo);
				}
				
			} catch ( SQLException ee ) {
				System.out.println(ee);
			} catch ( Exception e ) {
				System.out.println(e);
			} finally {
				try {
					if(rs!=null) {
						rs.close();
					}
					if(pstmt!=null) {
						pstmt.close();
					}
					if(con!=null) {
						con.close();
					}
				} catch ( SQLException e ) {
				}
			}
			
			return list;
		}//��� ��ȿ�� ����� �ҷ�����
	
	
	//���� ����ϱ�
	public boolean cancelBooking(String number) throws Exception {
		boolean result = false;
		
		//�������, 0��������, 1�����, 2���࿡��üũ�����γѾ, 
		//3����ܰ迡��������û�������, 4����ܰ迡���������, 5��Ÿ���������
		String sql = "update booking set bstatus=3 where bnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, number);
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
			} else {
				result = false;
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//���� ����ϱ�
	
	
	//���� ���� �̸����� �����ȣ �޾ƿ���
	public ArrayList<String> searchBookingnum(String number) throws Exception {
		ArrayList<String> list = new ArrayList<String>();
		String num;
		
		String sql = "select bnumber from booking where bstatus=1 and gnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, number);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				num = rs.getString(1);
				list.add(num);
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return list;
	}//���� ���� �̸����� �����ȣ �޾ƿ���
	
	
	//�����ȣ�� �������� ��������
	public BookingVO getBookinginfobyNum(String num) throws Exception {
		
		BookingVO bVo = new BookingVO();
		
		String sql = "select * from booking where bnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				bVo.setBnumber(rs.getString(1));
				bVo.setBdate(rs.getDate(2).toString());
				bVo.setBcheckin(rs.getDate(3).toString());
				bVo.setBcheckout(rs.getDate(4).toString());
				bVo.setBpeople(rs.getInt(5));
				bVo.setBpay(rs.getInt(6));
				if(rs.getInt(7)==0) {
					bVo.setBbreakfast(true);
				} else {
					bVo.setBbreakfast(false);
				}
				if(rs.getInt(8)==0) {
					bVo.setBlounge(true);
				} else {
					bVo.setBlounge(false);
				}
				if(rs.getInt(9)==0) {
					bVo.setBguidedog(true);
				} else {
					bVo.setBguidedog(false);
				}
				if(rs.getInt(10)==0) {
					bVo.setBparking(true);
				} else {
					bVo.setBparking(false);
				}
				bVo.setBcardcompany(rs.getString(11));
				bVo.setBcardnumber(rs.getString(12));
				bVo.setBstatus(rs.getInt(13));
				bVo.setGnumber(rs.getString(14));
				bVo.setRnumber(rs.getString(15));
			} else {
				System.out.println("����");
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return bVo;
	}//�����ȣ�� �������� ��������
	
	
	//üũ�� �Ǿ� ������� ���¸� 2�� �ٲٱ�
	public boolean updateBookingStatusIN(String bnumber) throws Exception {
		boolean result = false;
		
		//�������, 0��������, 1�����, 2���࿡��üũ�����γѾ, 
		//3����ܰ迡��������û�������, 4����ܰ迡���������, 5��Ÿ���������
		
		String sql = "update booking set bstatus=2 where bnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, bnumber);
			
			int i = pstmt.executeUpdate();
			
			if(i==1) {
				result = true;
				System.out.println(888);
			} else {
				result = false;
			}
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}//üũ�� �Ǿ� ������� ���¸� 2�� �ٲٱ�
	
	
	//�����ȣ�� �����ȣ�� �����ѹ� ��������
	public String getGnumberbyBnumber(String bnum) throws Exception {
		String gnum = null;
		
		String sql = "select gnumber from booking where bnumber=?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bnum);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				gnum = rs.getString(1);
			} else {
				gnum = "";
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return gnum;
	}//�����ȣ�� �����ȣ�� �����ѹ� ��������
	
	
	//��month �� ����� ��������
	public int gettotalbookingfeebyMonth(String month) throws Exception {
		int totalfee=0;
		
		String sql = "select bpay from booking where "
				+ " to_char(bdate,'mm')="+month+" and bstatus=2";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				totalfee += rs.getInt(1);
			}
			
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return totalfee;	
	}//��month �� ����� ��������
	
	
	//���� status�ٲٱ�
	public boolean updateStatus4byNoshow() throws Exception {
		//�������, 0��������, 1�����, 2���࿡��üũ�����γѾ, 
		//3����ܰ迡��������û�������, 4����ܰ迡���������, 5��Ÿ���������
		
		boolean result = false;
		
		String sql = "update booking set bstatus=4 where bcheckin<sysdate-1 and bstatus=1";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = true;
			} else {
				result = false;
			}
		} catch ( SQLException ee ) {
			System.out.println(ee);
		} catch ( Exception e ) {
			System.out.println(e);
		} finally {
			try {
				if(pstmt!=null) {
					pstmt.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch ( SQLException e ) {
			}
		}
		
		return result;
	}

}
